<?php

/**
 * Force le chargement d'un fichier pour l'afficher en brut
 *
 * syntaxe {up file-view=chemin fichier}
 *
 * Utilisation :
 * - charger du contenu récurrent à plusieurs pages
 * - voir un fichier CSV
 * - voir le code HTML
 *
 * @author   LOMART
 * @version  UP-1.6
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 * @tags    File
 *
 */
defined('_JEXEC') or die;

use Lomart\Plugin\Content\Up\Helper\UpHelper;

/*
 * v2.9 : l'option block est renomée main-tag
 * v3.1 : pas de bloc pour main-tag=0
 * v6.1.0 : check file type : allow only csv, txt, html 
 */

class file_view extends Lomart\Plugin\Content\Up\Extension\Up
{
    public function init()
    {
        // charger les ressources communes à toutes les instances de l'action
        return true;
    }

    public function run()
    {

        // lien vers la page de demo
        UpHelper::set_demopage($this);

        $options_def = array(
            __class__ => '', // chemin et nom du fichier
            /* [st-style] Style du bloc */
            'main-tag' => 'div', // balise principale. 0 pour aucune
            'class' => '', // classe(s) pour bloc
            'style' => '', // style inline pour bloc
            /* [st-format] Mise en forme du fichier */
            'HTML' => '0', // 0= aucun traitement, 1=affiche le code, ou liste des tags à garder (ex: img,a)
            'EOL' => '0', // forcer un retour à la ligne
            /* [st-annexe] style et options secondaires */
            'id' => '', // identifiant
            'css-head' => '', // règles CSS définies par le webmaster (ajout dans le head)
        );

        // fusion et controle des options
        $options = UpHelper::ctrl_options($this, $options_def);

        // Security : accept txt, html, csv files only
        $file = $options[__CLASS__];
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        if (in_array($ext, explode(',', 'txt,html,csv'))) {
            $type = 'text';
        } else {
            return UpHelper::msg_inline($this, UpHelper::lang($this, 'unauthorized_file: '.$file));
        }

        // === lecture et nettoyage fichier
        $content = UpHelper::get_html_contents($this, $options['file_view']);
        $content = UpHelper::clean_HTML($this, $content, $options['HTML'], $options['EOL']);
        // === css-head
        UpHelper::load_css_head($this, $options['css-head']);

        // contenu brut
        if (empty($options['main-tag'])) {
            return $content;
        }

        // attributs du bloc principal
        $attr_main = array();
        $attr_main['id'] = $options['id'];
        $attr_main['class'] = $options['class'];
        $attr_main['style'] = $options['style'];

        // code en retour
        return UpHelper::set_attr_tag($this, $options['main-tag'], $attr_main, $content);
    }

    // run
}

// class
