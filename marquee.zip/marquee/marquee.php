<?php

/**
 * contenu HTML défilant horizontalement ou verticalement
 *
 * {up marquee=label} texte du message défilant {/up marquee}
 *
 *
 * @author    Lomart
 * @version   UP-1.0
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 * @credit    <a href="http://www.jqueryscript.net/other/Smooth-Marquee-like-Content-Scroller-Plugin-For-jQuery-limarquee.html" target"_blank">script JS limarquee de omcg33</a>
 * @tags    layout-dynamic
 */
defined('_JEXEC') or die();

use Lomart\Plugin\Content\Up\Helper\UpHelper;

class marquee extends Lomart\Plugin\Content\Up\Extension\Up
{

    function init()
    {
        // charger les ressources communes à toutes les instances de l'action
        UpHelper::load_file($this,'liMarquee.css');
        UpHelper::load_file($this,'jquery.liMarquee.min.js');
        return true;
    }

    function run()
    {
        // cette action a obligatoirement du contenu
        if (! UpHelper::ctrl_content_exists($this)) {
            return false;
        }
        // lien vers la page de demo (vide=page sur le site de UP)
        UpHelper::set_demopage($this);

        // ==== la configuration par défaut de l'action
        $options_def = array(
            __class__ => '', // le texte de l'etiquette
            'model' => 'base', // style CSS dans .upmq-*style*. 0=aucun
            'height' => '100px', // hauteur defaut pour scroll vetical
            /* [st-css] Style CSS */
            'out-class' => '', // classe(s) pour div out
            'out-style' => '', // style inline pour div out
            'msg-class' => '', // classe(s) pour div msg
            'msg-style' => '', // style inline pour div msg
            'lbl-class' => '', // classe(s) pour div label
            'lbl-style' => '', // style inline pour div label
            'lbl-pos' => '', // position label : left, right, top, bottom, none
            'lbl-nowrap' => 0, // 1 = label sur une ligne
            /* [st-divers] Divers */
            'id' => '',  // identifiant
            'filter' => '' // conditions. Voir doc action filter (v1.8)
        );

        // ===== paramétres spécifique pour JS
        // traite a part pour avoir uniquement ceux indique
        $js_options_def = array(
        /* [st-JS] Paramètres Javascript pour configuration */
            'direction' => 'left', // right, up, down
            'loop' => - 1, // nombre d'affichage, -1 : infini
            'scrolldelay' => 0, // delai en millisecondes
            'scrollamount' => 50, // vitesse
            'circular' => 1, // mode carousel. si contenu plus large que .str_wrap
            'drag' => 1, // deplacement msg avec souris
            'runshort' => 1, // scroll si texte court (visible sans scroll)
            'hoverstop' => 1, // pause lors survol
            'inverthover' => 0 // scroll uniquement lors survol
        );

        // l'option principale est le texte label. Si non saisi = vide (pas true)
        // if ($options_user[$action]===true) $options_user[$action] = '';

        $options = UpHelper::ctrl_options($this,$options_def, $js_options_def);

        // === Filtrage
        if (UpHelper::filter_ok($this,$options['filter']) !== true) {
            return '';
        }

        $js_params = UpHelper::only_using_options($this,$js_options_def);
        $js_params = UpHelper::json_arrtostr($this,$js_params);

        // ==== code appel du plugin
        $js_code = '$("#' . $options['id'] . ' .str_wrap").liMarquee(' . $js_params . ');';
        UpHelper::load_jquery_code($this,$js_code);

        // == CONSOLIDATION OPTIONS
        // -- lbl-pos : nom verifie et complete pour faciliter CSS
        // si titre, lblpos doit être defini
        $tmp = array(
            'left' => 'lmmq-h-left',
            'right' => 'lmmq-h-right',
            'top' => 'lmmq-v-top',
            'bottom' => 'lmmq-v-bottom',
            'none' => ''
        );
        // si position definie, on la verifie et complete
        $class_label_pos = '';
        if ($options['lbl-pos'] && array_key_exists($options['lbl-pos'], $tmp)) {
            $class_label_pos = $tmp[$options['lbl-pos']];
        } else {
            // si titre, il faut la forcer
            // note: pas de reciproque. le titre peut etre en css
            if ($options[__class__] != 1) {
                $options['lbl-pos'] = 'left';
                $class_label_pos = $tmp['left'];
            }
        }

        // -- BLOC MAIN ----------------------------------------------
        $main_attr['id'] = $options['id'];
        // si demande utilisation fichier style CSS
        if ($options['model']) {
            UpHelper::load_file($this,'style/' . $options['model'] . '.css'); // TODO chemin
            $main_attr['class'] = 'lmmq-' . $options['model'];
        }

        // -- BLOC OUT ----------------------------------------------
        // -- les classes
        $out_attr['class'] = 'lmmq-out';
        UpHelper::add_class($this,$out_attr['class'], $class_label_pos);

        // les classes utilisateurs
        UpHelper::add_class($this,$out_attr['class'], $options['out-class']);

        // -- les styles
        $out_attr['style'] = $options['out-style'];
        if (! $class_label_pos) {
            UpHelper::add_style($this,$out_attr['style'], 'padding-right', '5px');
        }

        // -- BLOC LABEL ------------------------------------------------
        // les classes
        $lbl_attr['class'] = 'lmmq-lbl';

        // les styles
        $lbl_attr['style'] = $options['lbl-style'];
        if ($options['lbl-nowrap']) {
            UpHelper::add_style($this,$lbl_attr['style'], 'white-space', 'nowrap');
        }

        // -- MSG ------------------------------------------------
        $msg_attr['class'] = 'lmmq-msg';
        UpHelper::add_class($this,$msg_attr['class'], $options['msg-class']);
        // les styles
        $msg_attr['style'] = $options['msg-style'];

        // -- STR_WRAP -------------------------------------------
        // si scroll vertical, il faut forcer un height
        $wrap_attr['class'] = 'str_wrap';
        if (in_array(strtolower($options['direction']), array(
            'up',
            'down'
        ))) {
            $wrap_attr['style'] = 'height:' . $options['height'];
        }

        // ==== CODE RETOURNE POUR ACTION
        // outer
        $out = UpHelper::set_attr_tag($this,'div', $main_attr);
        $out .= UpHelper::set_attr_tag($this,'div', $out_attr);
        // label left ou top
        if (in_array($options['lbl-pos'], array(
            'left',
            'top'
        ))) {
            $out .= UpHelper::set_attr_tag($this,'div', $lbl_attr);
            $out .= ($options[__class__] == 1) ? '' : $options[__class__];
            $out .= '</div>';
        }
        $out .= UpHelper::set_attr_tag($this,'div', $msg_attr);
        $out .= UpHelper::set_attr_tag($this,'div', $wrap_attr);
        $out .= $this->content;
        $out .= '</div>';
        $out .= '</div>';
        // label right ou bottom
        if (in_array($options['lbl-pos'], array(
            'right',
            'bottom'
        ))) {
            $out .= UpHelper::set_attr_tag($this,'div', $lbl_attr);
            $out .= $options[__class__];
            $out .= '</div>';
        }
        $out .= '</div>';
        $out .= '</div>';

        return $out;
    }

    // run
}

// class
