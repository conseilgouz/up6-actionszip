<?php

/**
 * liste des catégories d'un mot-clé (tag)
 *
 * syntaxe : {up jcontent-by-tags=id-ou-nom-tag}
 * syntaxe : {up jcontent-by-tags=id-ou-nom-tag}##title##{/up jcontent-by-tags}
 *
 * <b>Les mots-clés :</b>
 * ##title## ##title-link## ##subtitle## ##link##
 * ##intro## ##intro-text## ##intro-text,100## ##content##
 * ##image## ##image-link## ##image-src## ##image-alt##
 * ##date-crea## ##date-modif##  ##date-publish##
 * ##cat## ##new## ##hits## ##tags-list##
 * ##CF_id_or_name## : valeur brute du custom field
 *
 * @author   LOMART
 * @version  UP-1.7
 * @license   <a href="http://www.gnu.org/licenses/gpl-3.0.html" target="_blank">GNU/GPLv3</a>
 * @tags    Joomla
 */
/*
 * v2.3 ajout motcles pour customFields : ##CF_id_or_name
 * v2.9 - compatibilité PHP8 pour ##date-xxx##
 * - le template peut être mis comme contenu
 * v3.0 bbcode possible sur template
 * v3.1
 *   - ajout option 'content-plugin'
 *   - prise en charge des mots -clés pour les customs-fields
 */
defined('_JEXEC') or die();

use Joomla\CMS\Access\Access;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Component\Content\Site\Model\ArticlesModel;
use Joomla\Database\DatabaseInterface;
use Lomart\Plugin\Content\Up\Helper\UpHelper;

class jcontent_by_tags extends Lomart\Plugin\Content\Up\Extension\Up
{
    public function init()
    {
        // charger les ressources communes à toutes les instances de l'action
        return true;
    }

    public function run()
    {
        // lien vers la page de demo (vide=page sur le site de UP)
        UpHelper::set_demopage($this);

        $options_def = array(
            __class__ => '', // ID ou nom du tag
            'maxi' => '', // Nombre maxi d'articles dans la liste
            'content-plugin' => 0, // prise en compte des plugins de contenu pour ##intro et ##content##
            'no-published' => '0', // 1 pour obtenir les catégories non publiées
            'current' => '0', // 1 pour inclure l'article en cours
            'sort-by' => 'title', // tri: title, created, modified, publish, id, hits, ordering
            'sort-order' => 'asc', // ordre de tri : asc, desc
            /* [st-model] Modèles de présentation */
            'template' => '', // modèle de mise en page. Si vide le modèle est le contenu
            /* [st-main] balise & style pour le bloc principal */
            'main-tag' => 'div', // balise pour le bloc englobant tous les articles. 0 pour aucun
            'id' => '', // identifiant
            'main-style' => '', // classes et styles inline pour bloc principal
            'main-class' => '', // classe(s) pour bloc principal (obsolète)
            /* [st-item] balise & style pour un élément */
            'item-tag' => 'div', // balise pour un bloc article. 0 pour aucun
            'item-style' => '', // classes et styles inline pour bloc principal
            'item-class' => '', // classe(s) pour bloc principal (obsoléte)
            /* [st-img] Paramètre pour l'image */
            'image-src' => '//lorempixel.com/150/150', // image par défaut
            'image-alt' => 'news', // image, texte alternatif par défaut
            /* [st-format] Format pour les mots-clés */
            'date-format' => '%e %B %Y', // format pour les dates
            'date-locale' => '', // localisation pour les dates. Par défaut, celle du navigateur client.
            'new-days' => '30', // nombre de jours depuis la création de l'article
            'new-html' => '[span class="badge-red"]nouveau[/span]', // code HTML pour badge NEW
            'tags-list-prefix' => '', // texte avant les autres éventuels tags
            'tags-list-style' => '', // classe ou style pour les autres mots-clés
            /* [st-divers] Divers */
            'no-content-html' => 'aucune catégorie pour ce mot-clé', // retour si aucune catégorie trouvée
            'css-head' => '' // style ajouté dans le HEAD de la page
        );

        // ======> fusion et controle des options
        $options = UpHelper::ctrl_options($this, $options_def);
        $options['template'] = UpHelper::get_bbcode($this, $options['template'], false);
        $options['new-html'] = UpHelper::get_bbcode($this, $options['new-html'], false);
        $options['no-content-html'] = UpHelper::get_bbcode($this, $options['no-content-html'], false);

        // ======> verif template (modèle de mise en page)
        // en priorité : le sontenu entre shortcode
        // en second : le model dans prefs.ini
        if ($this->content) {
            $tmpl = UpHelper::get_bbcode($this, $this->content); // v31
        } else {
            $tmpl = $options['template'];
        }
        if (empty($tmpl)) {
            UpHelper::msg_error($this, UpHelper::trad_keyword($this, 'NO_TEMPLATE'));
            return false;
        }
        $tmpl = UpHelper::get_bbcode($this, $tmpl, '+hr|pre'); // v31
        $title = '';
        // ==== ID du mot-clé
        if ((int) $options[__class__]) {
            $id = (int) $options[__class__];
        } else {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->createQuery();
            $query->select('t.id')
                ->from('#__tags as t')
                ->where('t.title = :title');
            $title = trim($options[__class__]);
            $query->bind(':title', $title, \Joomla\Database\ParameterType::STRING);
            $db->setQuery($query);
            $id = (int) $db->loadResult();
            if ($id === 0) {
                UpHelper::msg_error($this, UpHelper::trad_keyword($this, 'NO_TAG_NAME', $options[__class__]));
                return false;
            }
        }

        // =====> RECUP DES DONNEES
        // ---> contrôle clé de tri
        $list_sortkey = array(
            'title' => 'title',
            'ordering' => 'ordering',
            'created' => 'created',
            'modified' => 'modified',
            'publish' => 'publish_up',
            'id' => 'id',
            'hits' => 'hits'
        );
        $model     = new ArticlesModel(array('ignore_request' => true));
        $app       = Factory::getApplication();
        $appParams = $app->getParams();
        $model->setState('params', $appParams);
        $access     = true; // check user access level
        $authorised = Access::getAuthorisedViewLevels(Factory::getApplication()->getIdentity()->id);
        $model->setState('filter.access', $access); // check access
        $model->setState('filter.viewlevels', $authorised);
        $model->setState('filter.tag', $id);

        if (isset($list_sortkey[$options['sort-by']])) {
            $sort_by = $list_sortkey[$options['sort-by']];
        } else {
            UpHelper::msg_error($this, UpHelper::trad_keyword($this, 'SORT_NOT_FOUND', $options['sort-by'], implode(', ', array_keys($list_sortkey))));
            return false;
        }
        $sort_by = (isset($list_sortkey[$options['sort-by']])) ? $list_sortkey[$options['sort-by']] : 'title';

        $list_orderby = array('asc' => 'ASC', 'desc' => 'DESC', 'random' => 'RAND()');
        $order =  (isset($list_orderby[$options['sort-order']])) ? $list_orderby[$options['sort-order']] : '';
        if (strpos($order, 'ASC') !== false) {
            $model->setState('list.direction', 'ASC');
            $order = $sort_by;
        }
        if (strpos($order, 'DESC') !== false) {
            $model->setState('list.direction', 'DESC');
            $order = $sort_by;
        }
        if ($order == 'random') { // random order
            $order = 'RAND()';
        }
        $model->setState('list.ordering', $order);

        if ($options['maxi']) {
            $model->setState('list.start', 0);
            $model->setState('list.limit', (int)$options['maxi']);
            //            $query->setLimit((int)$options['maxi']);
        }

        if ($options['no-published'] != '1') {
            $model->setState('filter.published', 1);
            //$query->where('c.state=1');
        }

        if ($options['current'] == '0') {
            if (isset($this->article->id)) {
                $artid = $this->article->id;
            } else {
                $app = Factory::getApplication();
                $artid = (int)$app->getInput()->get('id', 0); // v2.5
            }
            $model->setState('filter.article_id', $artid);
            $model->setState('filter.article_id.include', false); // Exclude
        }
        $items = $model->getItems();
        if (count($items) == 0) {
            return $options['no-content-html'];
        }
        // ======> Style général et par catégorie
        $main_attr['id'] = $options['id'];
        UpHelper::get_attr_style($this, $main_attr, $options['main-class'], $options['main-style']);
        UpHelper::get_attr_style($this, $item_attr, $options['item-class'], $options['item-style']);
        UpHelper::get_attr_style($this, $tags_list_attr, $options['tags-list-style']);

        // css-head
        UpHelper::load_css_head($this, $options['css-head']);

        // ======> SORTIE HTML

        if ($options['main-tag'] != '0') {
            $html[] = UpHelper::set_attr_tag($this, $options['main-tag'], $main_attr);
        }

        foreach ($items as $item) {
            // --- Bloc catégorie
            if ($options['item-tag'] != '0') {
                $html[] = UpHelper::set_attr_tag($this, $options['item-tag'], $item_attr);
            }
            $sItem = $tmpl; // reinit pour nouvel article
            // --- lien vers l'article
            $url = '';
            $slug = ($item->alias) ? ($item->id . ':' . $item->alias) : $item->id;
            $catslug = ($item->category_alias) ? ($item->catid . ':' . $item->category_alias) : $item->catid;
            $route = RouteHelper::getArticleRoute($slug, $catslug);
            $url = Route::_($route);

            // --- le titre et sous titre
            $title = $item->title;
            $subtitle = '';
            if (stripos($sItem, '##subtitle##') !== false) {
                $title = strstr($item->title . '~', '~', true);
                $subtitle = trim(substr(strstr($item->title, '~'), 1));
            }

            // ==== les remplacements
            // {id} : ID de la categorie
            UpHelper::kw_replace($this, $sItem, 'id', $item->id);
            // {link} : lien vers le blog categorie - a mettre dans balise a
            UpHelper::kw_replace($this, $sItem, 'link', $url);
            // {title-link} : titre categorie avec lien
            UpHelper::kw_replace($this, $sItem, 'title-link', '<a href="' . $url . '">' . $title . '</a>');
            // {title} : titre categorie sans lien
            UpHelper::kw_replace($this, $sItem, 'title', $title);
            // {subtitle} : sous-titre categorie (partie après tilde du titre)
            UpHelper::kw_replace($this, $sItem, 'subtitle', $subtitle);
            // {date-crea} : date de création
            UpHelper::kw_replace($this, $sItem, 'date-crea', UpHelper::up_date_format($this, $item->created, $options['date-format'], $options['date-locale']));
            // {date-modif} : date de création
            UpHelper::kw_replace($this, $sItem, 'date-modif', UpHelper::up_date_format($this, $item->modified, $options['date-format'], $options['date-locale']));
            // {date-publish} : date de création
            UpHelper::kw_replace($this, $sItem, 'date-publish', UpHelper::up_date_format($this, $item->publish_up, $options['date-format'], $options['date-locale']));

            // {content} : texte en HTML
            // prise en charge plugins contenu v31
            if ($options['content-plugin']) {
                if (stripos($sItem, '##intro') !== false) {
                    $item->introtext = UpHelper::import_content($this, $item->introtext);
                } // v31
                if (stripos($sItem, '##content##') !== false) {
                    $item->fulltext = UpHelper::import_content($this, $item->fulltext);
                }
            }

            UpHelper::kw_replace($this, $sItem, 'intro', $item->introtext);
            UpHelper::kw_replace($this, $sItem, 'content', $item->fulltext);
            // {cat} : nom catégorie
            UpHelper::kw_replace($this, $sItem, 'cat', $item->category_title);
            // {tags-list} : liste des tags
            if (stripos($sItem, '##tags-list##') !== false) {
                $db = Factory::getContainer()->get(DatabaseInterface::class);
                $query = $db->createQuery();
                $query->select('t.title')
                    ->from('#__tags as t')
                    ->innerJoin('#__contentitem_tag_map as m on t.id = m.tag_id')
                    ->where('m.content_item_id = :id AND m.type_alias = :articlestr');
                $query->bind(':id', $item->id, \Joomla\Database\ParameterType::INTEGER);
                $str = "article";
                $query->bind(':articlestr', $str, \Joomla\Database\ParameterType::STRING);
                $db->setQuery($query);
                // $debug = $query->__toString();
                $listTags = $db->loadObjectList();

                $tmpTags = (empty($listTags)) ? '' : $options['tags-list-prefix'];
                foreach ($listTags as $tag) {
                    $tmpTags .= UpHelper::set_attr_tag($this, 'span', $tags_list_attr, $tag->title);
                }
                UpHelper::kw_replace($this, $sItem, 'tags-list', '<span>' . $tmpTags . '</span>');
            }
            // {new} : badge
            if (stripos($sItem, '##new##') !== false) {
                $max = date('Y-m-d H:i:s', mktime(date("H"), date("i"), 0, date("m"), date("d") - intval($options['new-days']), date("Y")));
                $new = ($item->created > $max) ? $options['new-html'] : '';
                UpHelper::kw_replace($this, $sItem, 'new', $new);
            }
            // {hits}
            UpHelper::kw_replace($this, $sItem, 'hits', $item->hits);
            // {image-xxx} : l'image d'intro, sinon celle dans l'introtext
            // {image} : la balise img complete
            // {image-src} et {image-alt} : uniquement src et alt d'une balise img existante
            if (stripos($sItem, '##image') !== false) {
                $params = json_decode($item->images);
                $img_src = $options['image-src'];
                $img_alt = $options['image-alt'];
                if ($params->image_intro) {
                    $img_src = $params->image_intro;
                    $img_alt = $params->image_intro_alt;
                } else {
                    $imgTag = UpHelper::preg_string($this, '#(\<img .*\>)#Ui', $item->fulltext);
                    if ($imgTag) {
                        $imgAttr = UpHelper::get_attr_tag($this, $imgTag, 'alt');
                        $img_src = $imgAttr['src'];
                        $img_alt = $imgAttr['alt'];
                    }
                }
                $imgtag = '<img src="' . $img_src . '" alt="' . $img_alt . '">';
                UpHelper::kw_replace($this, $sItem, 'image-link', '<a href="' . $url . '">' . $imgtag . '</a>');
                UpHelper::kw_replace($this, $sItem, 'image', $imgtag);
                UpHelper::kw_replace($this, $sItem, 'image-src', $img_src);
                UpHelper::kw_replace($this, $sItem, 'image-alt', $img_alt);
            }
            // --- tags avec param
            // ##intro-text,100## : les 100 premiers caractères de l'introduction en texte brut
            preg_match('#\#\#(intro-text\s*,?\s*([0-9]*)\s*)\#\##Ui', $sItem, $tag);
            if (isset($tag[1])) {
                $intro = ($item->introtext) ? $item->introtext : $item->fulltext;
                $intro = UpHelper::import_content($this, $intro);
                $intro = trim(strip_tags($intro));
                if (isset($tag[1]) && $tag[1]) {
                    $len = (int) $tag[2];
                    if (strlen($intro) > $len) {
                        $intro = mb_substr($intro, 0, $len) . '...';
                    }
                }
                UpHelper::kw_replace($this, $sItem, $tag[1], $intro);
            }


            // les custom fields (v3.1)
            if (strpos($sItem, '##') !== false) {
                require_once($this->upPath . '/assets/lib/kw_custom_field.php');
                kw_cf_replace($sItem, $item);
            }

            // --- fin article
            $html[] = $sItem;
            if ($options['item-tag'] != '0') {
                $html[] = '</' . $options['item-tag'] . '><!--item-->';
            }
        }
        if ($options['main-tag'] != '0') {
            $html[] = '</' . $options['main-tag'] . '><!--main-->';
        }

        return implode(PHP_EOL, $html);
    }

    // run
}

// class
